from modules.cli.cli_main import main
from modules.cli.figlet import print_header

if __name__ == "__main__":
    print_header()
    main()
